#define NUMERO_DE_CLIENTES 10

int clientes[] = {
	2,2,2,33,2,4,4,5,1,1
};
